import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-observable-demo',
  templateUrl: './observable-demo.component.html',
  styleUrls: ['./observable-demo.component.scss'],
})
export class ObservableDemoComponent implements OnInit {
  num;
  data: any;
  valueList=[];

  doCertainTask() {
    let num = new Promise((a, b) => {
      setTimeout(() => {
        console.log('Hello after 2 seconds');
        a(5);
      }, 2000);
    });
    return num;
  }

  // What if the num data has to come from server

  constructor() {
    this.doCertainTask().then((data) => {
      // console.log(data);
      this.num = data;
    });
  }

  ngOnInit(): void {
    this.data = new Observable((ob) => {
      setTimeout(() => {
        ob.next(12);
      }, 1000);
      setTimeout(() => {
        ob.next(13);
      }, 2000);
      setTimeout(() => {
        ob.next(14);
      }, 3000);
      setTimeout(() => {
        ob.next(15);
      }, 4000);
    });

    let subscription = this.data.subscribe((data) => {
      this.valueList.push(data);
      console.log(this.valueList);
    });
  }
}
