import { Injectable } from '@angular/core';

import { Router } from '@angular/router';
import {
  HttpClient,
  HttpHeaders,
  HttpErrorResponse,
  HttpParams,
} from '@angular/common/http';

import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

import { Note } from './../models/note';

@Injectable({
  providedIn: 'root',
})
export class NotesService {
  API_URL: string = 'http://localhost:3000';
  notes: any;
  headers = new HttpHeaders().set('Content-Type', 'application/json');

  constructor(private httpClient: HttpClient, public router: Router) {}

  addNote(note: Note): Observable<any> {
    // console.log(note);
    return this.httpClient
      .post(`${this.API_URL}/notes`, note)
      .pipe(catchError(this.handleError));
  }

  getAllNotes(): Observable<any> {
    return this.httpClient
      .get(`${this.API_URL}/notes`, { headers: this.headers })
      .pipe(
        map((res: Response) => {
          return res || {};
        }),
        catchError(this.handleError)
      );
  }
  deleteNote(id): Observable<any> {
    return this.httpClient
      .post(`${this.API_URL}/notes/delete`, {id})
      .pipe(catchError(this.handleError));
  }

  handleError(error: HttpErrorResponse) {
    let msg = '';
    if (error.error instanceof ErrorEvent) {
      // client-side error
      msg = error.error.message;
    } else {
      // server-side error
      msg = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(msg);
  }
}
