export class User {
  _id: String;
  email: String;
  password: String;
}
