export class Note {
  _id: String;
  title: String;
  type: String;
  content: Object;
  createdBy?: string;
}
