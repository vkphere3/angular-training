export class ToDo {
  element: String;
  completed: boolean;
}

