import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { AuthService } from './../../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss'],
})
export class RegisterComponent implements OnInit {
  registerForm: FormGroup;

  constructor(
    public formBuilder: FormBuilder,
    public authService: AuthService,
    public router: Router
  ) {
    this.registerForm = this.formBuilder.group({
      email: [''],
      password: [''],
    });
  }

  ngOnInit() {}

  registerUser() {
    if (
      this.registerForm.value.email !== '' &&
      this.registerForm.value.password !== ''
    ) {
      this.authService.register(this.registerForm.value).subscribe((res) => {
        this.registerForm.reset();
        this.router.navigate(['login']);
      });
    } else {
      alert('Please enter both email and the password!!');
    }
  }
}
