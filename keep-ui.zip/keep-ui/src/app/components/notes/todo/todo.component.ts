import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { NotesService } from 'src/app/services/notes.service';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.scss'],
})
export class TodoComponent implements OnInit {
  addTodoForm: FormGroup;
  todoList: any = [];
  constructor(
    public formBuilder: FormBuilder,
    public noteService: NotesService,
    public router: Router,
    private activatedRoute: ActivatedRoute
  ) {
    this.addTodoForm = this.formBuilder.group({
      task: [''],
      content: [''],
      type: [''],
      title: [''],
    });
    this.addTodoForm.setValue({
      task: '',
      content: '',
      type: 'todo',
      title: '',
    });
  }

  ngOnInit(): void {}

  addToList() {
    if (this.addTodoForm.value.task !== '') {
      this.todoList.push({
        task: this.addTodoForm.value.task,
        isCompleted: false,
      });
      this.addTodoForm.setValue({
        task: '',
        content: this.todoList,
        type: 'todo',
        title: '',
      });
    }
    else{
      alert("Please enter a task first to add it to the list")
    }

    // console.log(this.todoList);
  }

  removeTask(i) {
    //Deleting element at ith index in todoList
    this.todoList.splice(i, 1);
  }
  addTodoNote() {
    if (this.todoList.length !== 0) {
      this.noteService.addNote(this.addTodoForm.value).subscribe((res) => {
        this.addTodoForm.reset();
        this.todoList = [];
      });
    } else {
      alert('Please enter atleast one task');
    }
  }
}
