import { Component, OnInit } from '@angular/core';
import { NotesService } from 'src/app/services/notes.service';
import { Note } from 'src/app/models/note';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.scss'],
})
export class DisplayComponent implements OnInit {
  notes: any;

  constructor(
    private noteService: NotesService,
    private toastr: ToastrService
  ) {
    this.updateNotes();
  }

  updateNotes() {
    this.noteService.getAllNotes().subscribe((res) => {
      if (res.notes) {
        this.notes = res.notes;
      }
    });
  }
  ngOnInit(): void {}

  deleteNote(note) {
    console.log(note);
    this.noteService.deleteNote(note._id).subscribe(() => {
      this.updateNotes();
      this.toastr.success('Note deleted successfully');
    });
  }
}
