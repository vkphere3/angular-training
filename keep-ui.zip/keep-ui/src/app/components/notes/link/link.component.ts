import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { NotesService } from 'src/app/services/notes.service';

@Component({
  selector: 'app-link',
  templateUrl: './link.component.html',
  styleUrls: ['./link.component.scss'],
})
export class LinkComponent implements OnInit {
  addLinkForm: FormGroup;

  constructor(
    public formBuilder: FormBuilder,
    public noteService: NotesService,
    public router: Router,
    private activatedRoute: ActivatedRoute
  ) {
    this.addLinkForm = this.formBuilder.group({
      title: [''],
      content: [''],
      type: [''],
    });
    this.addLinkForm.setValue({ title: '', content: '', type: 'link' });
  }

  ngOnInit(): void {}

  addLinkNote() {
    if (
      this.addLinkForm.value.title !== '' ||
      this.addLinkForm.value.content !== ''
    ) {
      this.noteService.addNote(this.addLinkForm.value).subscribe((res) => {
        this.addLinkForm.reset();
      });
    } else {
      alert('Please enter Atleast the title or the content');
    }
    
    
  }
}
