import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { AuthService } from 'src/app/services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-notes',
  templateUrl: './notes.component.html',
  styleUrls: ['./notes.component.scss'],
})
export class NotesComponent implements OnInit {
  showNoteArea: Boolean = false;
  showTextNote: Boolean = false;
  showLinkNote: Boolean = false;
  showTodoNote: Boolean = false;
  showImageNote: Boolean = false;
  showMapNote: Boolean = false;
  

  constructor() {}

  ngOnInit(): void {}

  toggleShow() {
    this.showNoteArea = !this.showNoteArea;
  }

  openTextArea() {
    // this.toggleShow();
    this.showTextNote = !this.showTextNote;
    this.showLinkNote = false;
    this.showTodoNote = false;
    this.showImageNote = false;
    this.showMapNote = false;
  }
  openLinkArea() {
    // this.toggleShow();
    this.showTextNote = false;
    this.showLinkNote = !this.showLinkNote;
    this.showTodoNote = false;
    this.showImageNote = false;
    this.showMapNote = false;
  }

  openTodoArea() {
    // this.toggleShow();
    this.showTextNote = false;
    this.showLinkNote = false;
    this.showTodoNote = !this.showTodoNote;
    this.showImageNote = false;
    this.showMapNote = false;
  }

  openImageArea() {
    // this.toggleShow();
    this.showTextNote = false;
    this.showLinkNote = false;
    this.showTodoNote = false;
    this.showImageNote = !this.showImageNote;
    this.showMapNote = false;
  }

  openMapArea() {
    // this.toggleShow();
    this.showTextNote = false;
    this.showLinkNote = false;
    this.showTodoNote = false;
    this.showImageNote = false;
    this.showMapNote = !this.showMapNote;
  }
}
