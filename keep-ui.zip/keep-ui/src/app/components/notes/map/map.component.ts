import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { NotesService } from 'src/app/services/notes.service';

@Component({
  selector: 'app-map',
  templateUrl: './map.component.html',
  styleUrls: ['./map.component.scss'],
})
export class MapComponent implements OnInit {
  addMapForm: FormGroup;

  constructor(
    public formBuilder: FormBuilder,
    public noteService: NotesService,
    public router: Router,
    private activatedRoute: ActivatedRoute
  ) {
    this.addMapForm = this.formBuilder.group({
      title: [''],
      content: [''],
      type: [''],
    });
    this.addMapForm.setValue({ title: '', content: '', type: 'map' });
  }

  ngOnInit(): void {}

  addMapNote() {
    if (
      this.addMapForm.value.title !== '' ||
      this.addMapForm.value.content !== ''
    ) {
      this.noteService.addNote(this.addMapForm.value).subscribe((res) => {
        this.addMapForm.reset();
      });
    } else {
      alert('Please enter Atleast the title or the content');
    }
  }
}
