import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { NotesService } from 'src/app/services/notes.service';

@Component({
  selector: 'app-text',
  templateUrl: './text.component.html',
  styleUrls: ['./text.component.scss'],
})
export class TextComponent implements OnInit {
  addTextForm: FormGroup;

  constructor(
    public formBuilder: FormBuilder,
    public noteService: NotesService,
    public router: Router,
    private activatedRoute: ActivatedRoute
  ) {
    this.addTextForm = this.formBuilder.group({
      title: [''],
      content: [''],
      type: [''],
    });
    this.addTextForm.setValue({ title: '', content: '', type: 'text' });
  }

  ngOnInit(): void {}

  addTextNote() {
    if (
      this.addTextForm.value.title !== '' ||
      this.addTextForm.value.content !== ''
    ) {
      this.noteService.addNote(this.addTextForm.value).subscribe((res) => {
        this.addTextForm.reset();
      });
    } else {
      alert('Please enter Atleast the title or the content');
    }
   
  }
}
