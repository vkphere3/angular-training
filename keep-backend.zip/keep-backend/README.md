## Install dependencies

Run `npm install` to install all dependencies.

## Install Nodemon on global level

Run `npm i --global nodemon`

## Run the application

Run `npm start` will start the application. It will run on localhost:3000 by default.
