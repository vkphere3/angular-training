const expresss = require('express');
const router = expresss.Router();
const checkAuth = require('../middleware/check-auth');

const NoteController = require('../controllers/notes');

router.get('/',checkAuth, NoteController.notes_get_all);

router.post('/', checkAuth, NoteController.notes_create_note);
router.post('/delete', checkAuth, NoteController.notes_delete_note);


module.exports = router;