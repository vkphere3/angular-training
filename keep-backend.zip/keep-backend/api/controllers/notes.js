const mongoose = require('mongoose');

const Note = require('../model/note');

exports.notes_get_all = (req, res, next) => {
  // console.log(req.userData)
  Note.find({ createdBy: req.userData.email })
    .select('title type _id content createdBy')
    .exec()
    .then((docs) => {
      const response = {
        count: docs.length,
        notes: docs.map((doc) => {
          return {
            title: doc.title,
            type: doc.type,
            content: doc.content,
            _id: doc._id,
          };
        }),
      };
      console.log(docs);
      res.status(200).json(response);
    })
    .catch((err) => {
      console.log(err);
      res.status(500).json({
        error: err,
      });
    });
};

exports.notes_create_note = (req, res, next) => {
  const note = new Note({
    _id: new mongoose.Types.ObjectId(),
    title: req.body.title,
    type: req.body.type,
    content: req.body.content,
    createdBy: req.userData.email,
  });
  note
    .save()
    .then((result) => {
      console.log(result);
      res.status(200).json({
        message: 'New note created!',
        createdNote: {
          title: result.title,
          type: result.type,
          _id: result._id,
          content: result.content,
          createdBy: result.createdBy,
        },
      });
    })
    .catch((err) => {
      console.log(err);
      res.status(500).json({
        error: err,
      });
    });
};

exports.notes_delete_note = (req, res, next) => {
  const id = req.body.id;
  console.log(req.body)
  Note.deleteOne({ _id: mongoose.Types.ObjectId(id) })
    .exec()
    .then((result) => {
      console.log(result);
      res.status(200).json({
        message: 'Note deleted',
      });
    })
    .catch((err) => {
      console.log(err);
      res.status(500).json(err);
    });
};
